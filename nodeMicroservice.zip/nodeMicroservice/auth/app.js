const express = require('express');

const app = express();
const port=3003;
app.get('/auth', (req, res) => {
  res.send('authenticated');
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}!`);
});