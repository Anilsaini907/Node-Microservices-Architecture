const express = require('express');
const {createProxyMiddleware} = require('http-proxy-middleware');
const app = express();
const port = 8000;

const routes={
    '/users': 'http://localhost:3000',
    '/orders': 'http://localhost:3002',
    '/products': 'http://localhost:3001',
    '/auth': 'http://localhost:3003'
}

for (const route in routes) {
    const target=routes[route];
    app.use(route, createProxyMiddleware(target));
}

app.listen(port, () => {
    console.log(`Example app listening on port ${port}!`);
});